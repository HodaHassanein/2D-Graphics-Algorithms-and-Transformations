﻿using System;

using System.Drawing;

using System.Windows.Forms;


namespace dda
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int x1=Convert.ToInt16( textBox1.Text) + panel1.Height / 2; ;
            int x2= Convert.ToInt16(textBox2.Text) + panel1.Height / 2; ;
            int y1= -( Convert.ToInt16(textBox3.Text) ) + panel1.Height / 2; ;
            int y2= -(Convert.ToInt16(textBox4.Text)) + panel1.Height / 2; ;
            // Slope calculation
            int dx = x2 - x1, dy = y2 - y1, steps, k;
            double xIncrement, yIncrement, x = x1, y = y1;

            if (Math.Abs(dx) > Math.Abs(dy))
                steps = Math.Abs(dx);
            else
                steps = Math.Abs(dy);
            xIncrement = Convert.ToDouble(dx) / Convert.ToDouble(steps);
            yIncrement = Convert.ToDouble(dy) / Convert.ToDouble(steps);
            Brush brush = Brushes.Black;

            var g = panel1.CreateGraphics();
            g.FillRectangle(brush, Convert.ToInt16(Math.Round(x)), Convert.ToInt16( Math.Round(y)),1,1 );
            for (k = 0; k < steps; k++)
            {
                x += xIncrement;
                y += yIncrement;
                g.FillRectangle(brush, Convert.ToInt16(Math.Round(x)), Convert.ToInt16(Math.Round(y)), 1, 1);
            }
        }

        private void button2_Click(object sender, EventArgs e)

        {
            int x1 = Convert.ToInt16(textBox1.Text) + panel1.Height / 2;
            int x2 = Convert.ToInt16(textBox2.Text) + panel1.Height / 2;
            int y1 = -(Convert.ToInt16(textBox3.Text)) + panel1.Height / 2;
            int y2 = -(Convert.ToInt16(textBox4.Text)) + panel1.Height / 2;

            // Slope calculation
            int dx = Math.Abs(x2 - x1), dy = Math.Abs(y2 - y1);
            int sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1;
            int err = dx - dy, e2, x = x1, y = y1;

            Brush brush = Brushes.Black;
            var g = panel1.CreateGraphics();
            g.FillRectangle(brush, x, y, 1, 1);

            while (x != x2 || y != y2)
            {
                e2 = err << 1;
                if (e2 > -dy)
                {
                    err -= dy;
                    x += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y += sy;
                }
                g.FillRectangle(brush, x, y, 1, 1);
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Get the center point of the panel
            int centerX = panel1.Width / 2;
            int centerY = panel1.Height / 2;

            // Define the length of the horizontal and vertical lines
            int lineLength = panel1.Height;

            // Create a Pen object with desired color and width
            Pen pen = new Pen(Color.Black, 2);

            // Draw the horizontal line
            int startX = centerX - (lineLength / 2);
            int endX = centerX + (lineLength / 2);
            int y = centerY;
            e.Graphics.DrawLine(pen, startX, y, endX, y);

            // Draw the vertical line
            int x = centerX;
            int startY = centerY - (lineLength / 2);
            int endY = centerY + (lineLength / 2);
            e.Graphics.DrawLine(pen, x, startY, x, endY);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int x =Convert.ToInt32(textBox8.Text) + panel1.Height / 2;  // x-coordinate of center of ellipse
            int y = - Convert.ToInt32(textBox9.Text) + panel1.Height / 2;  // y-coordinate of center of ellipse
            int a = Convert.ToInt32(textBox10.Text);  // horizontal radius of ellipse
            int b = Convert.ToInt32(textBox11.Text);  // vertical radius of ellipse

            int a2 = a * a;
            int b2 = b * b;
            int twoA2 = 2 * a2;
            int twoB2 = 2 * b2;
            int x0 = 0;
            int y0 = b;
            int d = b2 - a2 * b + a2 / 4;
            int dx = twoB2 * x0;
            int dy = twoA2 * y0;

            Brush brush = Brushes.Black;
            var g = panel1.CreateGraphics();
            g.FillRectangle(brush, x + x0, y + y0, 1, 1);
            g.FillRectangle(brush, x - x0, y + y0, 1, 1);
            g.FillRectangle(brush, x + x0, y - y0, 1, 1);
            g.FillRectangle(brush, x - x0, y - y0, 1, 1);

            while (dx < dy)
            {
                x0++;
                dx += twoB2;
                if (d >= 0)
                {
                    y0--;
                    dy -= twoA2;
                    d -= dy;
                }
                d += dx + b2;
                g.FillRectangle(brush, x + x0, y + y0, 1, 1);
                g.FillRectangle(brush, x - x0, y + y0, 1, 1);
                g.FillRectangle(brush, x + x0, y - y0, 1, 1);
                g.FillRectangle(brush, x - x0, y - y0, 1, 1);
            }

            d = (int)(b2 * (x0 + 0.5) * (x0 + 0.5) + a2 * (y0 - 1) * (y0 - 1) - a2 * b2);

            while (y0 > 0)
            {
                y0--;
                dy -= twoA2;
                if (d <= 0)
                {
                    x0++;
                    dx += twoB2;
                    d += dx;
                }
                d += b2 - dy;
                g.FillRectangle(brush, x + x0, y + y0, 1, 1);
                g.FillRectangle(brush, x - x0, y + y0, 1, 1);
                g.FillRectangle(brush, x + x0, y - y0, 1, 1);
                g.FillRectangle(brush, x - x0, y - y0, 1, 1);
            }

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {





            int centerX = Convert.ToInt16(textBox5.Text) + panel1.Height / 2;
            int centerY = - Convert.ToInt16(textBox6.Text) + panel1.Height / 2;
            int radius = Convert.ToInt16(textBox7.Text);

            int x = 0;
            int y = radius;
            int d = 3 - 2 * radius;

            Brush brush = Brushes.Black;
            var g = panel1.CreateGraphics();
            g.FillRectangle(brush, centerX + x, centerY + y, 1, 1);
            g.FillRectangle(brush, centerX - x, centerY + y, 1, 1);
            g.FillRectangle(brush, centerX + x, centerY - y, 1, 1);
            g.FillRectangle(brush, centerX - x, centerY - y, 1, 1);
            g.FillRectangle(brush, centerX + y, centerY + x, 1, 1);
            g.FillRectangle(brush, centerX - y, centerY + x, 1, 1);
            g.FillRectangle(brush, centerX + y, centerY - x, 1, 1);
            g.FillRectangle(brush, centerX - y, centerY - x, 1, 1);

            while (y >= x)
            {
                x++;
                if (d > 0)
                {
                    y--;
                    d = d + 4 * (x - y) + 10;
                }
                else
                {
                    d = d + 4 * x + 6;
                }
                g.FillRectangle(brush, centerX + x, centerY + y, 1, 1);
                g.FillRectangle(brush, centerX - x, centerY + y, 1, 1);
                g.FillRectangle(brush, centerX + x, centerY - y, 1, 1);
                g.FillRectangle(brush, centerX - x, centerY - y, 1, 1);
                g.FillRectangle(brush, centerX + y, centerY + x, 1, 1);
                g.FillRectangle(brush, centerX - y, centerY + x, 1, 1);
                g.FillRectangle(brush, centerX + y, centerY - x, 1, 1);
                g.FillRectangle(brush, centerX - y, centerY - x, 1, 1);
            }
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
       
        private void button6_Click(object sender, EventArgs e)
        {
            int x1 = Convert.ToInt16(textBox1.Text);
            int x2 = Convert.ToInt16(textBox2.Text) ;
            int y1 = (Convert.ToInt16(textBox3.Text)) ;
            int y2 = (Convert.ToInt16(textBox4.Text));
            // Slope calculation
            int dx = x2 - x1, dy = y2 - y1, steps, k;
            double xIncrement, yIncrement, x = x1, y = y1;

            if (Math.Abs(dx) > Math.Abs(dy))
                steps = Math.Abs(dx);
            else
                steps = Math.Abs(dy);
            xIncrement = Convert.ToDouble(dx) / Convert.ToDouble(steps);
            yIncrement = Convert.ToDouble(dy) / Convert.ToDouble(steps);
            Brush brush = Brushes.Black;

            
           
            lblCoordinates.Text = $"({Math.Round(x)}, {Math.Round(y)})";

            for (k = 0; k < steps; k++)
            {
                x += xIncrement;
                y += yIncrement;
               
                lblCoordinates.Text += $", ({Math.Round(x)}, {Math.Round(y)})";
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {
            int x1 = Convert.ToInt16(textBox1.Text);
            int x2 = Convert.ToInt16(textBox2.Text);
            int y1 = (Convert.ToInt16(textBox3.Text));
            int y2 = (Convert.ToInt16(textBox4.Text));

            // Bresenham's line algorithm
            int dx = Math.Abs(x2 - x1);
            int dy = Math.Abs(y2 - y1);
            int sx = (x1 < x2) ? 1 : -1;
            int sy = (y1 < y2) ? 1 : -1;
            int err = dx - dy;
            int k = 0;
            int x = x1, y = y1;

            Brush brush = Brushes.Black;
            

            lblCoordinates.Text = $"({x}, {y})";

            while (x != x2 || y != y2)
            {
                int e2 = 2 * err;
                if (e2 > -dy)
                {
                    err -= dy;
                    x += sx;
                }
                if (e2 < dx)
                {
                    err += dx;
                    y += sy;
                }
                k++;
             
                lblCoordinates.Text += $", ({x}, {y})";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int centerX = Convert.ToInt16(textBox5.Text);
            int centerY = Convert.ToInt16(textBox6.Text);
            int radius = Convert.ToInt16(textBox7.Text);

            int x = 0;
            int y = radius; 
            int d = 3 - 2 * radius;

            Brush brush = Brushes.Black;
          

            string coordinates = $"({centerX + x},{centerY + y}) ({centerX - x},{centerY + y}) ({centerX + x},{centerY - y}) ({centerX - x},{centerY - y}) ({centerX + y},{centerY + x}) ({centerX - y},{centerY + x}) ({centerX + y},{centerY - x}) ({centerX - y},{centerY - x})";
            lblCoordinates.Text = coordinates;

            while (y >= x)
            {
                x++;
                if (d > 0)
                {
                    y--;
                    d = d + 4 * (x - y) + 10;
                }
                else
                {
                    d = d + 4 * x + 6;
                }

                coordinates = $"({centerX + x},{centerY + y}) ({centerX - x},{centerY + y}) ({centerX + x},{centerY - y}) ({centerX - x},{centerY - y}) ({centerX + y},{centerY + x}) ({centerX - y},{centerY + x}) ({centerX + y},{centerY - x}) ({centerX - y},{centerY - x})";
                lblCoordinates.Text = coordinates;

                
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(textBox8.Text);  // x-coordinate of center of ellipse
            int y = Convert.ToInt32(textBox9.Text);  // y-coordinate of center of ellipse
            int a = Convert.ToInt32(textBox10.Text);  // horizontal radius of ellipse
            int b = Convert.ToInt32(textBox11.Text);  // vertical radius of ellipse

            int a2 = a * a;
            int b2 = b * b;
            int twoA2 = 2 * a2;
            int twoB2 = 2 * b2;
            int x0 = 0;
            int y0 = b;
            int d = b2 - a2 * b + a2 / 4;
            int dx = twoB2 * x0;
            int dy = twoA2 * y0;

            string points = "";

            points += "(" + (x + x0) + ", " + (y + y0) + ")\n";
            points += "(" + (x - x0) + ", " + (y + y0) + ")\n";
            points += "(" + (x + x0) + ", " + (y - y0) + ")\n";
            points += "(" + (x - x0) + ", " + (y - y0) + ")\n";

            while (dx < dy)
            {
                x0++;
                dx += twoB2;
                if (d >= 0)
                {
                    y0--;
                    dy -= twoA2;
                    d -= dy;
                }
                d += dx + b2;

                points += "(" + (x + x0) + ", " + (y + y0) + ")\n";
                points += "(" + (x - x0) + ", " + (y + y0) + ")\n";
                points += "(" + (x + x0) + ", " + (y - y0) + ")\n";
                points += "(" + (x - x0) + ", " + (y - y0) + ")\n";
            }

            d = (int)(b2 * (x0 + 0.5) * (x0 + 0.5) + a2 * (y0 - 1) * (y0 - 1) - a2 * b2);

            while (y0 > 0)
            {
                y0--;
                dy -= twoA2;
                if (d <= 0)
                {
                    x0++;
                    dx += twoB2;
                    d += dx;
                }
                d += b2 - dy;

                points += "(" + (x + x0) + ", " + (y + y0) + ")\n";
                points += "(" + (x - x0) + ", " + (y + y0) + ")\n";
                points += "(" + (x + x0) + ", " + (y - y0) + ")\n";
                points += "(" + (x - x0) + ", " + (y - y0) + ")\n";
            }

            label1.Text = points;
        }

    }



}

